package martosjabonero.alberto.menu_principal_v02;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private MediaPlayer mp;
    private ViewPager2 viewPager2;
    private String incidencia,accidente,asistencia,ayuda,archivos;
    private ImageView info,audio;
    private TextView textoinfo;
    private int[] imagenes = {R.drawable.incidencia,R.drawable.accidente,R.drawable.asistencia,
            R.drawable.archivos, R.drawable.ayuda};
    private MenuAdapter menuAdapter;
    private int cont;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        info = findViewById(R.id.info);
        audio = findViewById(R.id.audio);
        textoinfo = findViewById(R.id.informacion);
        viewPager2=findViewById(R.id.viewpager);
        menuAdapter = new MenuAdapter(imagenes);
        viewPager2.setClipToPadding(false);
        viewPager2.setClipChildren(false);
        viewPager2.setOffscreenPageLimit(3);
        viewPager2.getChildAt(0).setOverScrollMode(View.OVER_SCROLL_NEVER);
        viewPager2.setAdapter(menuAdapter);
        incidencia = getResources().getString(R.string.incidencia);
        accidente = getResources().getString(R.string.accidente);
        asistencia = getResources().getString(R.string.asitencia);
        ayuda = getResources().getString(R.string.ayuda);
        archivos = getResources().getString(R.string.archivos);
        CompositePageTransformer transformer = new CompositePageTransformer();
        transformer.addTransformer(new MarginPageTransformer(40));
        transformer.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                float r = 1 - Math.abs(position);
                page.setScaleY(0.95f + r * 0.15f);
                page.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        switch (cont){
                            //case 0: toasted("Incidencia"); break;
                            case 0:  Intent incidencia = new Intent (view.getContext(), IncidenciaActivity.class);
                                     startActivity(incidencia);
                                     break;
                            case 1: toasted("accidente"); break;
                            case 2: toasted("asistencia"); break;
                            case 3: toasted("archivos"); break;
                            case 4: toasted("ayuda"); break;
                        }
                    }
                });
            }
        });
        viewPager2.setPageTransformer(transformer);
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                textoinfo.setText("");
                switch (position){
                    case 0: cont=0; break;
                    case 1: cont=1; break;
                    case 2: cont=2; break;
                    case 3: cont=3; break;
                    case 4: cont=4; break;
                    default: cont=0; break;
                }
            }
        });

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (cont){
                    case 0: textoinfo.setText(incidencia); break;
                    case 1: textoinfo.setText(accidente); break;
                    case 2: textoinfo.setText(asistencia); break;
                    case 3: textoinfo.setText(archivos); break;
                    case 4: textoinfo.setText(ayuda); break;
                    default: textoinfo.setText(""); break;
            }}
        });

        audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (cont){
                    case 0: mp=MediaPlayer.create(v.getContext(),R.raw.incidencia); break;
                    case 1: mp.stop();
                            mp=MediaPlayer.create(v.getContext(),R.raw.accidente); break;
                    case 2: mp.stop();
                        mp=MediaPlayer.create(v.getContext(),R.raw.asistencia); break;
                    case 3: mp.stop();
                        mp=MediaPlayer.create(v.getContext(),R.raw.documentos); break;
                    case 4: mp.stop();
                        mp=MediaPlayer.create(v.getContext(),R.raw.ayuda); break;
                }
                mp.start();
            }
        });

    }


    public void toasted(String s){
        Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
    }



}